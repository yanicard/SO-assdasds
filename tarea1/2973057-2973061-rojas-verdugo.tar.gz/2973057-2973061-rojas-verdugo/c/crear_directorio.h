#ifndef _CONJUNTO_H_
#define _CONJUNTO_H_

char* grades(int carrera);
int crear_carpetas(int length, char *sdir, int argc, char *argv);
int log_text(char *direccion, char *archivo, char *argv);
void mover_archivos(char *dir_actual, char *dir_nueva, char *archivo, char *argv);

#endif
